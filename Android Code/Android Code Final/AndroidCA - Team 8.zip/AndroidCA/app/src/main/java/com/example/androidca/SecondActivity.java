package com.example.androidca;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//Placeholder for second activity
public class SecondActivity extends AppCompatActivity implements View.OnClickListener{

    long MillisecondTime, StartTime, TimeBuff, UpdateTime = 0L ;
    android.os.Handler handler;
    TextView timer;
    int Seconds, Minutes;
    List<String> imageArr; //Coming from other side
    List<String> resultRandom;
    List<String> test;
    ImageView firstImage=null;
    ImageView secondImage=null;
    int count=0;

    private static Object lock = new Object();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        imageArr=new ArrayList<>();
        resultRandom=new ArrayList<>();
        Intent intent = getIntent();

        imageArr=intent.getStringArrayListExtra("imgList");
        for (String a:imageArr) {
            resultRandom.add(a);
            resultRandom.add(a);
        }
        NoRepeat(resultRandom);
        File file;
        for (int i=0; i<test.size(); i++) {
            int j=i+1;
            int id = getResources().getIdentifier("image" + j,
                    "id", getPackageName());
            try {
                file=new File(getFilesDir() + "/"+test.get(i));

                Bitmap bitmap = BitmapFactory.decodeStream(new FileInputStream(file));
                ImageView img = findViewById(id);
                img.setImageBitmap(bitmap);
                img.setTag(test.get(i));
                img.setOnClickListener(this);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        timer = findViewById(R.id.timer);
        handler=new Handler();
        StartTime = SystemClock.uptimeMillis();
        handler.postDelayed(runnable, 0);
        StartFlip();

    }

    public void NoRepeat(List<String> givenList) {
        Random rand = new Random();
        test=new ArrayList<>();
        for(int i=0;i<12;i++){
            int randomIndex = rand.nextInt(givenList.size());
            String randomElement = givenList.get(randomIndex);
            test.add(randomElement);
            givenList.remove(randomIndex);
        }
    }

    public void StartFlip(){
        for(int i=1;i<13;i++){
            int id = getResources().getIdentifier("image" + i,
                    "id", getPackageName());
            ImageView img=findViewById(id);
            img.setImageResource(R.drawable.cross);
        }
    }

    public Runnable runnable = new Runnable() {
        public void run() {
            MillisecondTime = SystemClock.uptimeMillis() - StartTime;
            UpdateTime = TimeBuff + MillisecondTime;
            Seconds = (int) (UpdateTime / 1000);
            Minutes = Seconds / 60;
            Seconds = Seconds % 60;
//            MilliSeconds = (int) (UpdateTime % 1000);
            timer.setText("" + Minutes + ":"
                            + String.format("%02d", Seconds) //+ ":"
                    //+ String.format("%03d", MilliSeconds)
            );
            handler.postDelayed(this, 0);
        }
    };

    public void showImg(ImageView img) throws FileNotFoundException {
        String Sid=img.getTag().toString();
        File file=new File(getFilesDir() + "/"+Sid);
        Bitmap bitmap = BitmapFactory.decodeStream(new FileInputStream(file));
        img.setImageBitmap(bitmap);
    }

    public void hideImg(ImageView img){
        ImageView v=findViewById(img.getId());
        v.setImageResource(R.drawable.cross);
    }

    @Override
    public void onClick(View view) {
        ImageView img = (ImageView) view;
        if(firstImage==null){
            firstImage=img;
            try {
                showImg(img);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            firstImage.setOnClickListener(null);
        }else if(firstImage!=null){
            secondImage=img;
            try {
                showImg(secondImage);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            if(firstImage.getTag()==secondImage.getTag()){
                firstImage.setOnClickListener(null);
                secondImage.setOnClickListener(null);
                firstImage=null;
                secondImage=null;
                count++;
                setText(count);
            }else{
                firstImage.setOnClickListener(this);
                secondImage.setOnClickListener(this);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        hideImg(secondImage);
                        hideImg(firstImage);

                        firstImage=null;
                        secondImage=null;
                    }
                },1000);
            }
        }
        if(count==6){
            Intent intent2 = new Intent(SecondActivity.this, MainActivity.class);
            startActivity(intent2);
        }
    }
    public void setText(int count){
        String res=count+" of 6 matches";
        TextView t=findViewById(R.id.counter);
        t.setText(res);
    }
}
