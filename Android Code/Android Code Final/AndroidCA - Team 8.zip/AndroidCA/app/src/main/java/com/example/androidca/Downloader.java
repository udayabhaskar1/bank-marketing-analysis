package com.example.androidca;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;

public class Downloader extends AsyncTask<String, Integer, Void> {
    private WeakReference<AppCompatActivity> caller;

    boolean carryon=true;

    public Downloader(WeakReference<AppCompatActivity> caller) {
        this.caller = caller;
    }

    @Override
    protected void onPreExecute()
    {
        AppCompatActivity activity = caller.get();
        ProgressBar bar = activity.findViewById(R.id.progressBar);
        TextView txtView = activity.findViewById(R.id.progText);
        bar.setProgress(0);
        bar.setVisibility(View.VISIBLE);
        String str = "Downloading 0 of 20 images";
        txtView.setVisibility(View.VISIBLE);
        txtView.setText(str);
        carryon=true;
    }

    @Override
    protected Void doInBackground(String... params)
    {
        String[] imgList = imageFinder(params[0]);
        imageGetter(imgList, params[1]);

        return null;
    }

    @Override
    protected void onProgressUpdate(Integer...values)
    {
        AppCompatActivity activity = caller.get();
        ProgressBar bar = activity.findViewById(R.id.progressBar);
        TextView txtView = activity.findViewById(R.id.progText);
        bar.setProgress(Math.round(values[0]));
        String prog = "Downloading " + values[1].toString() + " of 20 images";
        txtView.setText(prog);

        int id = activity.getResources().getIdentifier("imageView" + values[2], "id", activity.getPackageName());
        ImageView img = (ImageView) activity.findViewById(id);
        img.setClickable(true);
//      boolean bah = img.isClickable(); //For Debugging Purposes
        try {
            File file = new File(activity.getFilesDir() + "/a" + values[2]);
            Bitmap bitmap = BitmapFactory.decodeStream(new FileInputStream(file));
            img.setImageBitmap(bitmap);
        }
        catch(Exception e){
            e.printStackTrace();
        }

        if (values[1] == 20)
        {
            String comp = "Download Completed";
            txtView.setText(comp);
        }
    }

    private String[] imageFinder(String siteName) {
        String[] imgList = new String[20];
        int count = 0;

        try {
            URL url = new URL(siteName);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.addRequestProperty("User-Agent", "Mozilla/4.76");
            conn.connect();

            InputStream input = conn.getInputStream();

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(input));

            while ((bufferedReader.read()) != -1 && count < 20) {
                String line = bufferedReader.readLine();
                if (line.contains("img src") && !line.contains(".gif")) {
                    int firstQuoteMark = line.indexOf('"');
                    int secondQuoteMark = line.indexOf('"', firstQuoteMark + 1);

                    String imgLink = line.substring(firstQuoteMark + 1, secondQuoteMark);

                    imgList[count] = imgLink;
                    count++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return imgList;
    }

    private void imageGetter(String[] imgList, String fpath){
        int readLen = 0;


        for(int i = 0; i < imgList.length; i++)
        {
            try {
                URL url = new URL(imgList[i]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.addRequestProperty("User-Agent", "Mozilla/4.76");
                conn.connect();

                byte[] data = new byte[1024];

                InputStream input = conn.getInputStream();
                BufferedInputStream bufIn = new BufferedInputStream(input, 2048);
                OutputStream out = new FileOutputStream(fpath + "/a" + i);

                while ((readLen = bufIn.read(data)) != -1) {
                    out.write(data, 0, readLen);
                }
                if(carryon == false){
                    break;
                }
                publishProgress((int)((i + 1) * 100/imgList.length), i + 1, i);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void kill(){
        carryon=false;
    }
}
