package com.example.androidca;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    ArrayList<String> imgList;

    private final int NO_SELECT = 255;
    private final int SELECT = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgList = new ArrayList<String>();
//        imgList.add("a1");
//        imgList.add("a3");
//        imgList.add("a5");
//        imgList.add("a7");
//        imgList.add("a9");
//        imgList.add("a11");

        for(int i = 0; i < 20; i++)
        {
            int id = getResources().getIdentifier("imageView" + i, "id", getPackageName());
            ImageView img = (ImageView) findViewById(id);
            img.setClickable(true);
            img.setOnClickListener(this);
        }

//        Button fetch = (Button) findViewById(R.id.fetch);
//        fetch.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int count = 0;

        switch (v.getId())
        {
            case R.id.fetch:
            {
                //Code for stopping current task if running -- put here
                //If this task has already been run once, cancel the previous task

                for (int i = 0; i < 20; i++)
                {
                    int id = getResources().getIdentifier("imageView" + i, "id", getPackageName());
                    ImageView img = (ImageView) findViewById(id);
                    img.setImageResource(R.drawable.cross);
                    img.setClickable(false);
                    img.setOnClickListener(this);
                }

                imgList = new ArrayList<String>();
                EditText editText = (EditText) findViewById(R.id.search);
                String url = editText.getText().toString();
                new Downloader(new WeakReference<AppCompatActivity>(this)).execute(url, getFilesDir().toString());

                break;
            }
            case R.id.imageView0:
            {
                count = clickAction(R.id.imageView0, count, imgList, 0);
                break;
            }
            case R.id.imageView1:
            {
                count = clickAction(R.id.imageView1, count, imgList, 1);
                break;
            }
            case R.id.imageView2:
            {
                count = clickAction(R.id.imageView2, count, imgList, 2);
                break;
            }
            case R.id.imageView3:
            {
                count = clickAction(R.id.imageView3, count, imgList, 3);
                break;
            }
            case R.id.imageView4:
            {
                count = clickAction(R.id.imageView4, count, imgList, 4);
                break;
            }
            case R.id.imageView5:
            {
                count = clickAction(R.id.imageView5, count, imgList, 5);
                break;
            }
            case R.id.imageView6:
            {
                count = clickAction(R.id.imageView6, count, imgList, 6);
                break;
            }
            case R.id.imageView7:
            {
                count = clickAction(R.id.imageView7, count, imgList, 7);
                break;
            }
            case R.id.imageView8:
            {
                count = clickAction(R.id.imageView8, count, imgList, 8);
                break;
            }
            case R.id.imageView9:
            {
                count = clickAction(R.id.imageView9, count, imgList, 9);
                break;
            }
            case R.id.imageView10:
            {
                count = clickAction(R.id.imageView10, count, imgList, 10);
                break;
            }
            case R.id.imageView11:
            {
                count = clickAction(R.id.imageView11, count, imgList, 11);
                break;
            }
            case R.id.imageView12:
            {
                count = clickAction(R.id.imageView12, count, imgList, 12);
                break;
            }
            case R.id.imageView13:
            {
                count = clickAction(R.id.imageView13, count, imgList, 13);
                break;
            }
            case R.id.imageView14:
            {
                count = clickAction(R.id.imageView14, count, imgList, 14);
                break;
            }
            case R.id.imageView15:
            {
                count = clickAction(R.id.imageView15, count, imgList, 15);
                break;
            }
            case R.id.imageView16:
            {
                count = clickAction(R.id.imageView16, count, imgList, 16);
                break;
            }
            case R.id.imageView17:
            {
                count = clickAction(R.id.imageView17, count, imgList, 17);
                break;
            }
            case R.id.imageView18:
            {
                count = clickAction(R.id.imageView18, count, imgList, 18);
                break;
            }
            case R.id.imageView19:
            {
                count = clickAction(R.id.imageView19, count, imgList, 19);
                break;
            }
            default:
                break;
        }

        if (count == 6)
        {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("imgList", imgList);
            startActivity(intent);
        }
    }

    private int clickAction(int id, int count, ArrayList<String> imgList, int fileNo)
    {
        ImageView imgView = (ImageView) findViewById(id);
        String str = "a" + fileNo;
        if (imgView.getAlpha() == NO_SELECT)
        {
            imgView.setImageAlpha(SELECT);
            imgList.add(str);
            count++;
        }
        else if (imgView.getAlpha() == SELECT)
        {
            imgView.setImageAlpha(NO_SELECT);
            imgList.remove(str);
            count--;
        }
        return count;
    }
}
