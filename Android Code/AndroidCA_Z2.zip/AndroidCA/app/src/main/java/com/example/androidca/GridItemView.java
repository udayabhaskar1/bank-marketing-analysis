package com.example.androidca;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;

public class GridItemView extends FrameLayout {

    private ImageView imgView;

    public GridItemView(Context context) {
        super(context);
        LayoutInflater.from(context).inflate(R.layout.item_grid, this);
        imgView = (ImageView) getRootView().findViewById(R.id.img);
    }

    public void display(String text, boolean isSelected) {
        //imgView.setImgView();
        display(isSelected);
    }

    public void setImgView(File f)
    {
        try{
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            imgView.setImageBitmap(b);
        }catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    public void display(boolean isSelected) {
        imgView.setImageAlpha(isSelected ? 100 : 255);
    }

    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);    //Why use width measure twice?
    }
}
